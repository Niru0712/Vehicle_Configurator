import Trial2 from './Trial2';


function Interior (){
 
  
  return (
    <div>
    <div><h2>Interior Features</h2> </div>
    <Trial2 url = "interior"/>
    </div>
  )
}

export default Interior;
package com.example.services;

public interface Componentmanager {

}
